# Changelog

## v2.1.1 07/08/2015

*No changelog for this release.*

## v2.2.0 31/03/2017

Issue #69 #72: Added IPTC methods. New NPM release.
